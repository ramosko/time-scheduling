use std::collections::VecDeque;
use std::fs::File;
use std::io::{self, BufRead};
use std::path::Path;


struct Process {
    id: u32,
    burst_time: u32,
    arrived_time: u32,
    waiting_time: u32,
    roundturn: u32,
    remaining_time: u32,
}

impl Process {
    fn new(id: u32, burst_time: u32, arrived_time: u32) -> Self {
        Self {
            id,
            burst_time,
            arrived_time,
            waiting_time: 0,
            roundturn: 0,
            remaining_time: burst_time,
        }
    }
}



fn round_robin(processes: &mut VecDeque<Process>, time_slice: u32) {
    println!("Round-Robin Scheduling");
    let num_processes = processes.len() as u32;
    let mut time = 0;
    let mut total_waiting_time = 0;
    let mut total_roundturn_time = 0;
    let mut finished_processes = Vec::new();
    let mut c_processes = VecDeque::new();
    
    // Sorting processes by arrival time initially
    processes.make_contiguous().sort_by_key(|p| p.arrived_time);
    c_processes.push_back(processes.pop_front().unwrap());

    while num_processes != finished_processes.len() as u32 {
        // Move all processes that have arrived by the current time to the c_processes queue
        while let Some(front_process) = processes.front() {
            if front_process.arrived_time <= time {
                c_processes.push_back(processes.pop_front().unwrap());
            } else {
                break;
            }
        }
        
        if let Some(mut current_process) = c_processes.pop_front() {
            if current_process.remaining_time > time_slice {
                println!(
                    "Executing {} for {} time units",
                    current_process.id, time_slice
                );
                current_process.remaining_time -= time_slice;
                time += time_slice;
                while let Some(front_process) = processes.front() {
                    if front_process.arrived_time <= time {
                        c_processes.push_back(processes.pop_front().unwrap());
                    } else {
                        break;
                    }
                }
                c_processes.push_back(current_process);
            } else {
                println!(
                    "Executing {} for {} time units",
                    current_process.id, current_process.remaining_time
                );
                time += current_process.remaining_time;
                current_process.roundturn = time - current_process.arrived_time;
                current_process.waiting_time = current_process.roundturn - current_process.burst_time;
                total_waiting_time += current_process.waiting_time;
                total_roundturn_time += current_process.roundturn;
                finished_processes.push(current_process);
            }
        } else {
            // If no processes are available to execute, increment time
            time += 1;
        }
    }

    let num_processes = finished_processes.len() as u32;
    let avg_waiting_time = total_waiting_time as f32 / num_processes as f32;
    let avg_roundturn_time = total_roundturn_time as f32 / num_processes as f32;

    println!("Average Waiting Time: {:.2}", avg_waiting_time);
    println!("Average Round-Turn Time: {:.2}", avg_roundturn_time);
}


fn fcfs(processes: &mut VecDeque<Process>) {
    print!("First-Come First-Served Scheduling\n");
    let num_processes = processes.len() as u32;
    let mut time = 0;
    let mut total_waiting_time = 0;
    let mut total_roundturn_time = 0;
    processes.make_contiguous().sort_by_key(|p| p.arrived_time);

    while !processes.is_empty() {
        let mut current_process = processes.pop_front().unwrap();
        if current_process.arrived_time > time {
            time = current_process.arrived_time;
        }
        println!("Executing {} for {} time units", current_process.id, current_process.burst_time);
        time += current_process.burst_time;
        current_process.roundturn = time - current_process.arrived_time;
        current_process.waiting_time = current_process.roundturn - current_process.burst_time;
        total_waiting_time += current_process.waiting_time;
        total_roundturn_time += current_process.roundturn;
    }

   
    let avg_waiting_time = total_waiting_time as f32 / num_processes as f32;
    let avg_roundturn_time = total_roundturn_time as f32 / num_processes as f32;

    println!("Average Waiting Time: {:.2}", avg_waiting_time);
    println!("Average Round-Turn Time: {:.2}", avg_roundturn_time);
}

fn srtf(processes: &mut VecDeque<Process>) {
    println!("Shortest Remaining Time First Scheduling");

    let mut time = 0;
    let mut total_waiting_time = 0;
    let mut total_roundturn_time = 0;
    let mut finished_processes = Vec::new();
    let mut active_processes = VecDeque::new();

    processes.make_contiguous().sort_by_key(|p| p.arrived_time);

    while !processes.is_empty() || !active_processes.is_empty() {
        // Add new processes that have arrived to the active queue
        while let Some(front_process) = processes.front() {
            if front_process.arrived_time <= time {
                active_processes.push_back(processes.pop_front().unwrap());
            } else {
                break;
            }
        }

        // Find the process with the shortest remaining time that has arrived
        let mut shortest_process_index = None;
        let mut shortest_remaining_time = u32::MAX;

        for (i, process) in active_processes.iter().enumerate() {
            if process.remaining_time < shortest_remaining_time {
                shortest_process_index = Some(i);
                shortest_remaining_time = process.remaining_time;
            }
        }

        if let Some(shortest_index) = shortest_process_index {
            let mut current_process = active_processes.remove(shortest_index).unwrap();
            
            // Calculate the next arrival time to handle incoming processes
            let next_arrival_time = if let Some(next_process) = processes.front() {
                next_process.arrived_time
            } else {
                time + current_process.remaining_time
            };

            // Execute the process until next arrival or until it finishes
            let execute_time = (next_arrival_time - time).min(current_process.remaining_time);
            println!(
                "Executing {} for {} time units (remaining: {})",
                current_process.id, execute_time, current_process.remaining_time - execute_time
            );
            current_process.remaining_time -= execute_time;
            time += execute_time;

            if current_process.remaining_time == 0 {
                // Process finished
                current_process.roundturn = time - current_process.arrived_time;
                current_process.waiting_time = current_process.roundturn - current_process.burst_time;
                total_waiting_time += current_process.waiting_time;
                total_roundturn_time += current_process.roundturn;
                finished_processes.push(current_process);
            } else {
                // Put the process back in the queue if not finished
                active_processes.push_back(current_process);
            }
        } else {
            // If no active processes, increment time to the next arrival time
            if let Some(next_process) = processes.front() {
                time = next_process.arrived_time;
            }
        }
    }

    let num_processes = finished_processes.len() as u32;
    let avg_waiting_time = total_waiting_time as f32 / num_processes as f32;
    let avg_roundturn_time = total_roundturn_time as f32 / num_processes as f32;

    println!("Average Waiting Time: {:.2}", avg_waiting_time);
    println!("Average Round-Turn Time: {:.2}", avg_roundturn_time);
}



fn main() -> io::Result<()> {
    
    let mut processes = VecDeque::new();
    processes.push_back(Process::new(4, 4, 2));
    processes.push_back(Process::new(2, 2, 3));
    processes.push_back(Process::new(3, 5, 3));
    processes.push_back(Process::new(1, 4, 5));
    srtf(&mut processes);
    

    let mut processes1 = VecDeque::new();
    // processes1.push_back(Process::new(1, 10, 0));
    // processes1.push_back(Process::new(2, 5, 1));
    // processes1.push_back(Process::new(3, 8, 2));
    // processes1.push_back(Process::new(4, 2, 3));
    // fcfs(&mut processes1);
    

    
    let file = File::open("input.txt")?;
    let reader = io::BufReader::new(file);

    
    for line in reader.lines() {
        let line = line?;

       
        let numbers: Vec<i32> = line
            .split_whitespace()
            .map(|s| s.parse().expect("parse error"))
            .collect();

        
        if numbers.len() >= 3 
        {
           
            let (num1, num2, num3) = (numbers[0], numbers[1], numbers[2]);
            processes1.push_back(Process::new(num1 as u32, num2 as u32, num3 as u32));
            // println!("Num1: {}, Num2: {}, Num3: {}", num1, num2, num3);
        } else 
        {
            println!("error: not enough numbers in line");
        }
    }
    // fcfs(&mut processes1);

    Ok(())




}